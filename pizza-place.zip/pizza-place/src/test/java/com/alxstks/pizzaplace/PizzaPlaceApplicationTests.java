package com.alxstks.pizzaplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaPlaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
