package com.alxstks.pizzaplace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaPlaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzaPlaceApplication.class, args);
	}

}
